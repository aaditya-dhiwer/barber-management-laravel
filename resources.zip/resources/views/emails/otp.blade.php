<p>Your OTP is: <strong>{{ $otp }}</strong></p>
<p>This OTP is valid for 10 minutes.</p>
