<!DOCTYPE html>
<html>

<body>
    <p>You requested a password reset.</p>
    <p><a href="{{ $url }}">Click here to reset your password</a></p>
    <p>If you didn’t request this, you can ignore this email.</p>
</body>

</html>
