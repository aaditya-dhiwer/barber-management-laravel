<p>Your OTP is: <strong><?php echo e($otp); ?></strong></p>
<p>This OTP is valid for 10 minutes.</p>
<?php /**PATH D:\Aaditya\laravel\barber_management\resources\views/emails/otp.blade.php ENDPATH**/ ?>